#!/bin/sh

workdir=${PWD}
gst=$1

for r in `gresource list $gst`; do
	target="$workdir/$r"
	targetdir="${target%/*}"
	if [ ! -d ${targetdir} ]; then
	  mkdir -p ${targetdir}
	fi
        gresource extract $gst $r >$target
done
